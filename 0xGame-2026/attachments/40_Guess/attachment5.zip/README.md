# Guessing Game

这是一个 Python PYC 逆向入门题。

## 选手附件

- `dist/attachment.exe`：Windows x64 控制台程序
- `dist/attachment.zip`：发布压缩包

程序会随机生成 0 到 100 的数字，并给出五次猜测机会。猜中时程序会显示一个假 flag；真正的 flag 没有直接输出。

## 运行

```text
Welcome to 0xGame2026!
Let's play a game now.
You have five chances to guess the number（0-100）
```

目标是逆向附件，恢复程序内部保存的真实 flag。
