# Simple-AI-chat

这是一个真实的AI 聊天工具。

## 功能

- 命令行多轮对话，输入 `exit`、`quit` 或 `退出` 结束
- 基于 OpenAI Responses API，通过 `previous_response_id` 保持上下文
- 可通过 `OPENAI_MODEL` 切换模型

## 项目结构

```
├── chat.py          # 主程序
├── config.json      # 模型参数配置
├── .env             # API key 等环境变量配置
├── requirements.txt # 依赖列表
```

安装依赖：

```powershell
python -m pip install -r requirements.txt
```

在项目根目录的 `.env` 文件中配置 API Key（程序通过 python-dotenv 自动加载）：

```
OPENAI_API_KEY="你的 API Key"
```

运行：

```powershell
python chat.py
```

默认模型是 `gpt-5.6`。如需切换模型，可修改 `.env` 中的 `OPENAI_MODEL`。



## 常见问题

- **401 Unauthorized**：检查 API Key 是否正确配置
- **请求超时**：适当调大 `TIMEOUT` 的值
- **切换模型**：修改 `OPENAI_MODEL` 或 `config.json`
