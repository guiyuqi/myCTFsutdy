"""一个简单的命令行 AI 聊天程序。"""

import json
import os
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

CONFIG_PATH = Path(__file__).with_name("config.json")
SYSTEM_PROMPT = "你是一个友好、简洁的中文 AI 助手。"


def load_config() -> dict:
    with CONFIG_PATH.open(encoding="utf-8") as f:
        return json.load(f)


def main() -> None:
    if not os.getenv("OPENAI_API_KEY"):
        print("错误：请先设置环境变量 OPENAI_API_KEY。")
        print('PowerShell 示例：$env:OPENAI_API_KEY="你的 API Key"')
        return

    config = load_config()
    client = OpenAI()
    model = os.getenv("OPENAI_MODEL", config.get("model", "gpt-5.6"))
    previous_response_id: str | None = None

    print(f"AI 聊天已启动（模型：{model}）")
    print("输入 exit、quit 或 退出 即可结束。\n")

    while True:
        try:
            user_input = input("你：").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n再见！")
            break

        if not user_input:
            continue
        if user_input.lower() in {"exit", "quit"} or user_input == "退出":
            print("再见！")
            break

        try:
            request = {
                "model": model,
                "instructions": SYSTEM_PROMPT,
                "input": user_input,
                "max_output_tokens": config.get("max_tokens", 512),
            }
            if previous_response_id:
                request["previous_response_id"] = previous_response_id

            response = client.responses.create(**request)
            previous_response_id = response.id
            print(f"AI：{response.output_text}\n")
        except Exception as exc:
            print(f"请求失败：{exc}\n")


if __name__ == "__main__":
    main()
