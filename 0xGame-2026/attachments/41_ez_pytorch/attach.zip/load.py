import torch

model = torch.load("model.pth", weights_only=True)
print("model loaded:", model)

# better experience: Python3.11+ torch >= 2.6
